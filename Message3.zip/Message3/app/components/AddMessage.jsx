var React = require("react");
var actions = require("../actions/MessageAction");

module.exports = React.createClass({
    getInitialState:function(){
      return {
          messageId:"",
          messageTitle:"",
          message:"",
          messageCategory:this.props.service,
          postBy:"",
          postDate:""
      }  
    },
    addMessage:function(e){
        e.preventDefault();
        console.log("addMessage = ",this.state);
        actions.addMessage(this.state);
    },
    handleInputChange:function(e){
      e.preventDefault();
      var name = e.target.name;
      var state = this.state;
      state[name] = e.target.value;
      this.setState(state);
    },
    render:function(){
        return(
            <form className="form" onSubmit={this.addMessage}>
                <div className="form-group">
                    <label className="control-label" htmlFor="name">Message Title:</label>
                    <input type="text" className="form-control" id="messageTitle" name="messageTitle" value={this.state.messageTitle} onChange={this.handleInputChange} placeholder="Title" />                    
                </div>
                <div className="form-group">
                    <label className="control-label" htmlFor="area">Content:</label>
                </div>
                <div className="panel-heading">
                    <textarea id="message" rows="10" cols="74" name="message" value={this.state.message} onChange={this.handleInputChange} placeholder="Post your content here..." />
                </div>
                <div className="form-group">
                    <label className="control-label" htmlFor="tagline">Post By:</label>
                    <input type="text" className="form-control" id="postBy" name="postBy" value={this.state.postBy} onChange={this.handleInputChange} placeholder="Post by" />                    
                </div>
                 <div className="form-group">
                    <label className="control-label" htmlFor="tagline">Post By:</label>
                    <input type="text" className="form-control" id="postDate" name="postDate" value={this.state.postDate} onChange={this.handleInputChange} placeholder="Post Date" />                    
                </div>
                <div className="form-group">
                    <button className="btn" type="submit">Post</button>
                </div>
            </form>
        )
    }
})