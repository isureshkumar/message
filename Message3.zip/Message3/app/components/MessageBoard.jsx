var React = require("react");
var ReactDOM = require("react-dom");
var Header = require("./Header.jsx");
var MessageTitles = require("./MessageTitles.jsx");
var messageStore = require("../stores/messageStore");

var _messages = [];
var getMessagesCallback = function(messages) {
    _messages = messages;
    console.log(_messages);
};
messageStore.onChange(getMessagesCallback);
module.exports = React.createClass({
    getInitialState:function(){
        console.log(_messages);
        return {}
    },
    render:function(){
        return (
            <div>
                <Header service={this.props.service}/>
                <MessageTitles allMessages={_messages}/>
            </div>
        )
    }
});