var React = require("react");
var actions = require("../actions/MessageAction");

module.exports = React.createClass({
    deleteMessage: function(e){
        e.preventDefault();
        actions.deleteMessage(this.props.info);
    },
    render:function(){
        return(
            <div>
                <div className="panel panel-default">
                    <div className="panel-heading">
                        <span>{this.props.info.messageId} : {this.props.info.messageTitle}</span>
                        <span className="pull-right text-uppercase delete-button" onClick={this.deleteMessage}>&times;</span>
                        <span className="panel-heading pull-right text-uppercase">{this.props.info.postBy}</span>
                        <span className="panel-heading pull-right text-uppercase ">{this.props.info.postDate}</span>
                    </div>
                    <div className="panel-body">{this.props.info.message}</div>
                </div>
                <div className="form-group">
                    <label className="control-label" htmlFor="area">Reply:</label>
                </div>
                <div className="panel-heading">
                    <textarea id="message" rows="4" cols="90" name="reply" placeholder="Reply here..."/>
                </div>
                <div className="form-group">
                    <button className="btn" type="submit">Reply</button>
                </div>
                <div>
                {
                    this.props.info.replies != null && this.props.info.replies != undefined &&
                        this.props.info.replies.map(function(reply,index){
                            return(
                                <div className="panel panel-default">
                                    <div className="panel-heading">
                                        <span className="panel-heading">Reply : {reply.commentedBy}</span>
                                        <span className="panel-heading pull-right text-uppercase ">{reply.commentedOn}</span>
                                    </div>
                                    <div className="panel-body">{reply.comment}</div>
                                </div>
                            )         
                        }
                    )
                }
                </div>
            </div>
        )
    }
})
