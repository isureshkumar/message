var React = require("react");
var ReactDOM = require("react-dom");
var MessageBoard = require("./MessageBoard.jsx");

function redirect(action) {
    console.log("action =",action);
    ReactDOM.render(<MessageBoard service={action}/>, document.getElementById("container"));
}
module.exports = React.createClass({
    onClick: function(event){
      redirect(action);
    },
    render:function(){
        return(
            <div id="messagelist" className="row">
                <div className="list-group">
                    <a onClick={function(event){ redirect('MessageBoard');}} className="list-group-item text-center">
                        <h4 className="glyphicon"></h4>Message Board
                    </a>
                    <a onClick={function(event){ redirect('CRM');}} className="list-group-item text-center">
                        <h4 className="glyphicon"></h4>CRM
                    </a>
                    <a onClick={function(event){ redirect('ACOL');}} className="list-group-item text-center active">
                        <h4 className="glyphicon"></h4>ACOL
                    </a>
                    <a onClick={function(event){ redirect('AdeguataVerifica');}} className="list-group-item text-center">
                        <h4 className="glyphicon"></h4>AdeguataVerifica
                    </a>
                    <a onClick={function(event){ redirect('Onboarding');}} className="list-group-item text-center">
                        <h4 className="glyphicon"></h4>Onboarding
                    </a>
                    <a onClick={function(event){ redirect('Dashboard');}} className="list-group-item text-center">
                        <h4 className="glyphicon"></h4>Dashboard
                    </a>
                    <a onClick={function(event){ redirect('PWE');}} className="list-group-item text-center">
                        <h4 className="glyphicon"></h4>PWE
                    </a>
                </div>
            </div>
        )
    }
});