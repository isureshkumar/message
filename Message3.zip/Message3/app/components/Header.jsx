var React = require("react");
var ReactDOM = require("react-dom");
var AddMessage = require("./AddMessage.jsx");
var service;
function postMessage() {
    console.log("service = "+service);
    ReactDOM.render(<AddMessage service={service}/>, document.getElementById("container"));
}
function onClickAction(action) {
    console.log("onClickAction service = "+service);
    if("postMessage" == action) {
        postMessage();
    }
}
module.exports = React.createClass({
    getInitialState:function(){
        console.log(this.props.service);
        service = this.props.service;
        return {}
    },
    onClick: function(event){
      onClickAction(action);
    },
    render:function(){
        return(
            <div id="messagelist" className="row">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <span><button class = "btn btn-default" onClick={function(event){ onClickAction('postMessage');}}>Post</button></span>
                    </div>
                </div>
            </div>
        )
    }
});