var dispatcher = require("../dispatcher");
var messageService = require("../services/messageService");

function MessageStore() {
    var listeners = [];

    function onChange(listener) {
        getMessages(listener);
        listeners.push(listener);
    }
    
    function getMessages(cb){
        messageService.getMessages().then(function (res) {
            cb(res.messages);
        });
    }

    function addMessage(message) {
        messageService.addMessage(message).then(function (res) {
            console.log(res);
            triggerListeners();
        });
    }

    function deleteMessage(message) {
        messageService.deleteMessage(message).then(function (res) {
            console.log(res);
            triggerListeners();
        });
    }

    function triggerListeners() {
        getMessages(function (res) {
            listeners.forEach(function (listener) {
                listener(res);
            });
        });
    }

    dispatcher.register(function (payload) {
        var split = payload.type.split(":");
        if (split[0] === "message") {
            switch (split[1]) {
                case "addMessage":
                    addMessage(payload.message);
                    break;
                case "deleteMessage":
                    deleteMessage(payload.message);
                    break;
            }
        }
    });

    return {
        onChange: onChange
    }
}

module.exports = MessageStore();