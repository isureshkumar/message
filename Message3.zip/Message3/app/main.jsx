var React = require("react");
var ReactDOM = require("react-dom");
var Components = require("./components/Components.jsx");
ReactDOM.render(<Components/>, document.getElementById("components"));
