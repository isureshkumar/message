package com.netboard.message.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Reply {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long replyId;
	String comment;
	String commentedBy;
	String commentedOn;

	public Long getReplyId() {
		return replyId;
	}

	public void setReplyId(Long replyId) {
		this.replyId = replyId;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getCommentedBy() {
		return commentedBy;
	}

	public void setCommentedBy(String commentedBy) {
		this.commentedBy = commentedBy;
	}

	public String getCommentedOn() {
		return commentedOn;
	}

	public void setCommentedOn(String commentedOn) {
		this.commentedOn = commentedOn;
	}

	@Override
	public String toString() {
		return "ReplyBO [replyId=" + replyId + ", comment=" + comment
				+ ", commentedBy=" + commentedBy + ", commentedOn="
				+ commentedOn + "]";
	}

}
