package com.netboard.message.dao;

import java.util.HashMap;
import java.util.List;

import com.netboard.message.dto.Message;

public class MessageDAO extends AbstractDAO<Message> {
	
	public MessageDAO() {
		super();
	}

	public Message save(Message msg) {
		return super.save( msg );
	}

	public List<Message> findAll() {
		String sqlData = "SELECT m FROM Message m";
		return super.findEntityObj(sqlData, new HashMap<String, String>());
	}

}

