package com.netboard.message.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.netboard.message.dao.MessageDAO;
import com.netboard.message.dto.Message;

public class MessageController {
	private static final Logger logger = LoggerFactory.getLogger(MessageController.class);

	public void addMessages(Message message) {
		MessageDAO messageDao = new MessageDAO();
		messageDao.save(message);
	}

	public List<Message> getMessages() {
		logger.debug("getMessages >>>>>>>>>>>>>>>>>>>>>>");
		MessageDAO messageDao = new MessageDAO();
		List<Message> msgList = messageDao.findAll();
		logger.debug("msgList = "+msgList);
		return msgList;
	}

}
