var React = require("react");
var ReactDOM = require("react-dom");
var MessageInfo = require("./MessageInfo.jsx");

function displayMessage(message) {
    ReactDOM.render(<MessageInfo info={message.message}/>, document.getElementById("container"));
}
module.exports = React.createClass({
    onClick: function(event){
      displayMessage(message);
    },
    render:function(){
       return(
           <div className="row">
               <div className="col-md-6">
                    {
                        this.props.allMessages.map(function(message,index){
                            return(
                                <li onClick={function(event){ displayMessage({message});}} key={index}>{message.messageTitle}</li>
                            )         
                        })
                    }
                </div>
           </div>
       )
   } 
});