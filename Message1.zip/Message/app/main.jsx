var React = require("react");
var ReactDOM = require("react-dom");

var MessageBoard = require("./components/MessageBoard.jsx");
var Components = require("./Components.jsx");
//var MessageTitles = require("./components/MessageTitles.jsx");

ReactDOM.render(<Components/>, document.getElementById("components"));
