var $ = require("jquery");
var promise = require("es6-promise");
var resourceUrl = "http://localhost:8080/NetBoard/messageboard/";
module.exports = {
    addMessage: function (message) {
        var Promise = promise.Promise;
        var url = resourceUrl+"postMessage";
        return new Promise(function (resolve, reject) {
            $.ajax({
                url: url,
                data: JSON.stringify(message),
                method: "POST",
                dataType: "json",
                contentType: "application/json",
                crossDomain: true,
                success: resolve,
                error: reject
            });
        });
    },
    getMessages: function () {
        var Promise = promise.Promise;
        var url = resourceUrl+"getMessages";
        var data;
        var response = new Promise(function (resolve, reject) {
            $.ajax({
                url: url,
                method: "GET",
                dataType: "json",
                success: resolve,
                error: reject
            });
        });
        
        return response;
    },
    deleteMessage: function (message) {
        var Promise = promise.Promise;
        return new Promise(function (resolve, reject) {
            $.ajax({
                url: resourceUrl + "/" + message.messageId,
                method: "DELETE",
                dataType: "json",
                success: resolve,
                error: reject
            });
        });
    }
}