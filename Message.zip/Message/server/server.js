var express = require("express");
var bodyParser = require("body-parser");
var path = require("path");

//Express request pipeline
var app = express();
app.use(express.static(path.join(__dirname, "../app/dist")));
app.use(bodyParser.json())

app.listen(7777, function () {
    console.log("Started listening on port", 7777);
});