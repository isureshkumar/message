var React = require("react");
var ReactDOM = require("react-dom");
var messageStore = require("./stores/messageStore");
var MessageBoard = require("./components/MessageBoard.jsx");
var Components = require("./components/Components.jsx");
//var MessageTitles = require("./components/MessageTitles.jsx");
var messages = [];
var getMessagesCallback = function(messages){
    _messages = messages;
     render();
};
messageStore.onChange(getMessagesCallback);
function render() {
    ReactDOM.render(<Components/>, document.getElementById("components"));
    ReactDOM.render(<MessageBoard messages={_messages}/>, document.getElementById("container"));
}