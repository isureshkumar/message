var React = require("react");
var ReactDOM = require("react-dom");
var MessageBoard = require("./MessageBoard.jsx");
var messages = [];

function redirect(action) {
    if("MessageBoard" == action) {
        ReactDOM.render(<MessageBoard/>, document.getElementById("container"));
    } else if("CRM" == action) {
        ReactDOM.render(<MessageBoard/>, document.getElementById("container"));
    } else if("ACOL" == action) {
        ReactDOM.render(<MessageBoard/>, document.getElementById("container"));
    } else if("AdeguataVerifica" == action) {
        ReactDOM.render(<MessageBoard/>, document.getElementById("container"));
    } else if("Onboarding" == action) {
        ReactDOM.render(<MessageBoard/>, document.getElementById("container"));
    } else if("Dashboard" == action) {
        ReactDOM.render(<MessageBoard/>, document.getElementById("container"));
    } else if("PWE" == action) {
        ReactDOM.render(<MessageBoard/>, document.getElementById("container"));
    }
}
module.exports = React.createClass({
    onClick: function(event){
      redirect(action);
    },
    render:function(){
        return(
            <div id="messagelist" className="row">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <div><button class = "btn btn-default" onClick={function(event){ redirect('MessageBoard');}}>Message Board</button></div>
                        <div><button class = "btn btn-default" onClick={function(event){ redirect('CRM');}}>CRM</button></div>
                        <div><button class = "btn btn-default" onClick={function(event){ redirect('ACOL');}}>ACOL</button></div>
                        <div><button class = "btn btn-default" onClick={function(event){ redirect('AdeguataVerifica');}}>AdeguataVerifica</button></div>
                        <div><button class = "btn btn-default" onClick={function(event){ redirect('Onboarding');}}>Onboarding</button></div>
                        <div><button class = "btn btn-default" onClick={function(event){ redirect('Dashboard');}}>Dashboard</button></div>
                        <div><button class = "btn btn-default" onClick={function(event){ redirect('PWE');}}>PWE</button></div>
                    </div>
                </div>
            </div>
        )
    }
});