var React = require("react");
var MessageInfo = require("./MessageInfo.jsx")
var AddMessage = require("./AddMessage.jsx");

module.exports = React.createClass({
   render:function(){
       return(
           <div className="row">
                <div className="col-md-6">
                    <AddMessage />
                </div>
                <div className="col-md-6">
                    {
                        this.props.messages.map(function(message,index){
                            return(
                                <MessageInfo info={message} key={"message"+index} />
                            )         
                        })
                    }
                </div>
           </div>
       )
   } 
});
