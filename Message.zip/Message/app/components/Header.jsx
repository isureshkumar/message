var React = require("react");
var ReactDOM = require("react-dom");
var AddMessage = require("./AddMessage.jsx");
var messages = [];
function postMessage() {
    ReactDOM.render(<AddMessage/>, document.getElementById("container"));
}
function displayMessages() {
    renderMessageTitles();
}
function onClickAction(action) {
    if("postMessage" == action) {
        postMessage();
    } else if("displayMessages" == action) {
        displayMessages();
    }
}
module.exports = React.createClass({
    onClick: function(event){
      onClickAction(action);
    },
    render:function(){
        return(
            <div id="messagelist" className="row">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <span class="navbar-brand" href="#">Message Board</span>
                        <span><button class = "btn btn-default" onClick={function(event){ onClickAction('displayMessages');}}>Read Messages</button></span>
                        <span><button class = "btn btn-default" onClick={function(event){ onClickAction('postMessage');}}>Post</button></span>
                    </div>
                </div>
            </div>
        )
    }
});