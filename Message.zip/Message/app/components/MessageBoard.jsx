var React = require("react");
var ReactDOM = require("react-dom");
var Header = require("./Header.jsx");
var MessageTitles = require("./MessageTitles.jsx");
//var messageStore = require("./stores/messageStore");

var messages = [];
// var getMessagesCallback = function(messages){
//     _messages = messages;
//     render();
// };
// messageStore.onChange(getMessagesCallback);

module.exports = React.createClass({
    getInitialState:function(){
        messages = this.props.messages;
        render();
    },
    render:function(){
    }
});
function render() {
    ReactDOM.render(<MessageTitles allMessages={messages}/>, document.getElementById("container"));
}
