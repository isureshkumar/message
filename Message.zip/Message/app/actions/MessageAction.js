var dispatcher = require("../dispatcher");

module.exports = {
    addMessage:function(message){
        dispatcher.dispatch({
           message:message,
           type:"message:addMessage" 
        });
    },
    deleteMessage:function(message){
        dispatcher.dispatch({
           message:message,
           type:"message:deleteMessage" 
        });
    }
}