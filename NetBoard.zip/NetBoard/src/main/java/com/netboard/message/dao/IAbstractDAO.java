package com.netboard.message.dao;




public interface IAbstractDAO<T> {

    void delete(Object id);

    T find(Object id);

    T update(T t);

	T create(T msg);

}
