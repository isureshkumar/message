package com.netboard.message.dao;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AbstractDAO<T> {

	private static final Logger logger = LoggerFactory
			.getLogger(AbstractDAO.class);

	EntityManagerFactory emfactory = Persistence
			.createEntityManagerFactory("NetBoard");

	/*
	 * em.getTransaction().begin(); this.em.persist(msg);
	 * em.getTransaction().commit(); private Class<T> type;
	 * 
	 * @SuppressWarnings("unchecked") public AbstractDAO() { em =
	 * emfactory.createEntityManager(); Type t =
	 * getClass().getGenericSuperclass(); ParameterizedType pt =
	 * (ParameterizedType) t; type = (Class) pt.getActualTypeArguments()[0]; }
	 */
	@PersistenceContext
	private EntityManager em;

	// @PostConstruct
	public AbstractDAO() {
		em = emfactory.createEntityManager();
		logger.debug("AbstractDAO init ...." + em);
	}

	public T save(T t) {
		em.getTransaction().begin();
		em.persist(t);
		em.getTransaction().commit();
		return t;
	}

	protected T saveAndUpdate(T t) {
		em.getTransaction().begin();
		em.merge(t);
		em.getTransaction().commit();
		return t;
	}

	protected Query createQuery(final String query) {
		return em.createQuery(query);
	}

	protected T findEntityObj(Class<T> entityClass, Object pKey) {
		T entityObj = em.find(entityClass, pKey);
		return entityObj;
	}

	protected List<T> findEntityObj(String sqlData,	Map<String, String> paramList) {
		Query query = this.em.createQuery(sqlData);
		for (Map.Entry<String, String> param : paramList.entrySet()) {
			query.setParameter(param.getKey(), param.getValue());
		}
		return (List<T>) query.getResultList();
	}

	/*protected List<T> findEntityObj(String sqlData,	Map<String, String> paramList) {
		TypedQuery<Message> query = this.em.createQuery(sqlData, Message.class);
		for (Map.Entry<String, String> param : paramList.entrySet()) {
			query.setParameter(param.getKey(), param.getValue());
		}
		return (List<T>) query.getResultList();
	}*/

	protected void delete(T t) {
		em.getTransaction().begin();
		t = em.merge(t); // merge and assign a to the attached entity
		em.remove(t); // remove the attached entity
		em.getTransaction().commit();
	}
}