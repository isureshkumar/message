package com.netboard.message.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.netboard.message.dto.Message;
import com.netboard.message.dto.ResponseBO;

@Controller
@RequestMapping("/messageboard")
class IndexController
{
    private static final Logger logger = LoggerFactory.getLogger(IndexController.class);
    
    MessageController messageController = new MessageController();
    
    @RequestMapping(value="/postMessage",produces="application/x-www-form-urlencoded",method={RequestMethod.POST})
    public @ResponseBody ResponseBO postMessage(final @RequestBody Message message)
    {
    	logger.debug("postMessage = "+message);
    	messageController.addMessages(message);
        return getMessages();
    }
    @RequestMapping(value="/getMessages",produces="application/json",method={RequestMethod.GET})
    public @ResponseBody ResponseBO getMessages()
    {
    	ResponseBO responseBO = new ResponseBO();
    	responseBO.setMessages(messageController.getMessages());
        return responseBO;
    }
}
