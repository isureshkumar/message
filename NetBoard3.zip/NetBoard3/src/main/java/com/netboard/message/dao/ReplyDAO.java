package com.netboard.message.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.netboard.message.dto.Reply;

public class ReplyDAO extends AbstractDAO<Reply> {
	
	public ReplyDAO() {
		super();
	}

	public Reply save(Reply msg) {
		return super.save( msg );
	}

	public List<Reply> findAll(Long messageId) {
		String sqlData = "SELECT r FROM Reply r";
		Map<String, String> params = new HashMap<String, String>();
		params.put("messageId", messageId.toString());
		return super.findEntityObj(sqlData, params);
	}

}

