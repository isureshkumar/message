package com.netboard.message.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.netboard.message.dto.Message;
import com.netboard.message.dto.Reply;
import com.netboard.message.dto.ResponseBO;

@Controller
@RequestMapping("/messageboard")
class IndexController
{
    private static final Logger logger = LoggerFactory.getLogger(IndexController.class);
    
    MessageController messageController = new MessageController();
    
    @CrossOrigin
    @RequestMapping(value="/postMessage",produces="application/json",method={RequestMethod.POST})
    public @ResponseBody ResponseBO postMessage(final @RequestBody Message message)
    {
    	logger.debug("postMessage = "+message);
    	messageController.addMessages(message);
        return getMessages();
    }
    @RequestMapping(value="/getMessages",produces="application/json",method={RequestMethod.GET})
    public @ResponseBody ResponseBO getMessages()
    {
    	ResponseBO responseBO = new ResponseBO();
    	responseBO.setMessages(messageController.getMessages());
        return responseBO;
    }
    @CrossOrigin
    @RequestMapping(value="/postReply",produces="application/json",method={RequestMethod.POST})
    public @ResponseBody List<Reply> postMessage(final @RequestBody Reply reply)
    {
    	logger.debug("postReply = "+reply);
    	messageController.addReply(reply);
        return getReplies(reply.getReplyMessageId());
    }
    @RequestMapping(value="/getReplies",produces="application/json",method={RequestMethod.GET})
    public @ResponseBody List<Reply> getReplies(Long messageId)
    {
    	List<Reply> replies = new ArrayList<Reply>();
    	replies = messageController.getReplies(messageId);
        return replies;
    }
}
