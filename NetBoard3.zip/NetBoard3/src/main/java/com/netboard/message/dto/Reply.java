package com.netboard.message.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="replies")
public class Reply {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="reply_id")
	Long replyId;
	@Column(name="reply_msg_id")
	Long replyMessageId;
	@Column(name="reply_comment")
	String replyComment;
	@Column(name="reply_comment_by")
	String replyCommentedBy;
	@Column(name="reply_comment_on")
	String replyCommentedOn;

	public Long getReplyId() {
		return replyId;
	}

	public void setReplyId(Long replyId) {
		this.replyId = replyId;
	}

	public Long getReplyMessageId() {
		return replyMessageId;
	}

	public void setReplyMessageId(Long replyMessageId) {
		this.replyMessageId = replyMessageId;
	}

	public String getReplyComment() {
		return replyComment;
	}

	public void setReplyComment(String replyComment) {
		this.replyComment = replyComment;
	}

	public String getReplyCommentedBy() {
		return replyCommentedBy;
	}

	public void setReplyCommentedBy(String replyCommentedBy) {
		this.replyCommentedBy = replyCommentedBy;
	}

	public String getReplyCommentedOn() {
		return replyCommentedOn;
	}

	public void setReplyCommentedOn(String replyCommentedOn) {
		this.replyCommentedOn = replyCommentedOn;
	}

	@Override
	public String toString() {
		return "Reply [replyId=" + replyId + ", replyMessageId=" + replyMessageId
				+ ", replyComment=" + replyComment + ", replyCommentedBy=" + replyCommentedBy
				+ ", replyCommentedOn=" + replyCommentedOn + "]";
	}

}
