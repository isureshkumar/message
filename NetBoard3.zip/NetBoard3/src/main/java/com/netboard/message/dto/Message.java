package com.netboard.message.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="message")
public class Message {

	@Id
	@Column(name="msg_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long messageId;
	@Column(name="msg_title")
	String messageTitle;
	@Column(name="msg")
	String message;
	@Column(name="msg_category")
	String messageCategory;
	@Column(name="post_date")
	String postDate;
	@Column(name="post_by")
	String postBy;
	@OneToMany(targetEntity=Reply.class,cascade=CascadeType.ALL)
	@JoinColumn(name="reply_msg_id")
	List<Reply> replies;

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getMessageTitle() {
		return messageTitle;
	}

	public void setMessageTitle(String messageTitle) {
		this.messageTitle = messageTitle;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessageCategory() {
		return messageCategory;
	}

	public void setMessageCategory(String messageCategory) {
		this.messageCategory = messageCategory;
	}

	public String getPostDate() {
		return postDate;
	}

	public void setPostDate(String postDate) {
		this.postDate = postDate;
	}

	public String getPostBy() {
		return postBy;
	}

	public void setPostBy(String postBy) {
		this.postBy = postBy;
	}

	public List<Reply> getReplies() {
		return replies;
	}

	public void setReplies(List<Reply> replies) {
		this.replies = replies;
	}

	@Override
	public String toString() {
		return "Message [messageId=" + messageId + ", messageTitle="
				+ messageTitle + ", message=" + message + ", messageCategory="
				+ messageCategory + ", postDate=" + postDate + ", postBy="
				+ postBy + ", replies=" + replies + "]";
	}
}
