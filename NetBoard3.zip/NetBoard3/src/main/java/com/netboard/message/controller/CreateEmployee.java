package com.netboard.message.controller;

import java.util.ArrayList;
import java.util.List;

import com.netboard.message.dao.MessageDAO;
import com.netboard.message.dto.Message;

public class CreateEmployee {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Message message = new Message();
		// message.setMessageId(messageId);
		message.setMessage("Message");
		message.setMessageTitle("Message");
		message.setPostBy("Suresh");
		message.setPostDate("22/05/1988");
		MessageDAO messageDao = new MessageDAO();
		//messageDao.save(message);
		List<Message> msgList = new ArrayList<Message>();
		msgList = messageDao.findAll();
		System.out.println("msgList = "+msgList);

	}
}